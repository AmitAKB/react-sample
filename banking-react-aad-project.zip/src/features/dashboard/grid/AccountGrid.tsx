import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";

const AccountGrid = () => {
  const rowData = [
    { accountNo: "12345", name: "Amit", balance: 50000 },
  ];

  const columnDefs = [
    { field: "accountNo" },
    { field: "name" },
    { field: "balance" },
  ];

  return (
    <div className="ag-theme-alpine" style={{ height: 400 }}>
      <AgGridReact rowData={rowData} columnDefs={columnDefs} />
    </div>
  );
};

export default AccountGrid;
