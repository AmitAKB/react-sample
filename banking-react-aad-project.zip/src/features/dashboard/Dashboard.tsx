import AccountGrid from "./grid/AccountGrid";

const Dashboard = () => (
  <div>
    <h1>Banking Dashboard</h1>
    <AccountGrid />
  </div>
);

export default Dashboard;
