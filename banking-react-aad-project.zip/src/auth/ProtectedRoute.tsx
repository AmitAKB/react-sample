import { useIsAuthenticated } from "@azure/msal-react";

export const ProtectedRoute = ({ children }: { children: JSX.Element }) => {
  const isAuthenticated = useIsAuthenticated();
  return isAuthenticated ? children : <div>Authenticating...</div>;
};
