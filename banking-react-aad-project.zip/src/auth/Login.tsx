import { useMsal } from "@azure/msal-react";
import { loginRequest } from "./msalConfig";

const Login = () => {
  const { instance } = useMsal();

  return (
    <button onClick={() => instance.loginRedirect(loginRequest)}>
      Login with Bank Azure AD
    </button>
  );
};

export default Login;
