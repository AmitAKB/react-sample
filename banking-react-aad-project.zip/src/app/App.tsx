import Login from "../auth/Login";
import Dashboard from "../features/dashboard/Dashboard";
import { useIsAuthenticated } from "@azure/msal-react";

const App = () => {
  const isAuthenticated = useIsAuthenticated();
  return isAuthenticated ? <Dashboard /> : <Login />;
};

export default App;
