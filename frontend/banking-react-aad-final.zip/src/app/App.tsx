import { useIsAuthenticated } from "@azure/msal-react";
import Login from "../auth/Login";
import Dashboard from "../features/dashboard/Dashboard";

export default function App() {
  const isAuthenticated = useIsAuthenticated();
  return isAuthenticated ? <Dashboard /> : <Login />;
}
