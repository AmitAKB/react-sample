import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";

export default function AccountGrid() {
  const rowData = [
    { accountNo: "123456", customer: "Amit", balance: 50000 }
  ];

  const columnDefs = [
    { field: "accountNo" },
    { field: "customer" },
    { field: "balance" }
  ];

  return (
    <div className="ag-theme-alpine" style={{ height: 400 }}>
      <AgGridReact rowData={rowData} columnDefs={columnDefs} />
    </div>
  );
}
