import AccountGrid from "./grid/AccountGrid";

export default function Dashboard() {
  return (
    <div>
      <h1>Banking Dashboard</h1>
      <AccountGrid />
    </div>
  );
}
